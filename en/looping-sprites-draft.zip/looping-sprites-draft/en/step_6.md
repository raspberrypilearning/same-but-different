## Share your project

If you are in a club, why not demonstrate your project to friends and peers?

If you are at home, try the project out with your family. 

If you have a Scratch account you can share your project through Scratch. Then you can send a link to people you know and the whole Scratch community will be able to find your project and try it out.

[[[share-scratch]]]

Why not invite your friends to create a project? Let them know how you had fun.
