## Add more sprites
Now you've got one sprite moving the way you want it to, you can add more. 

--- task ---
Duplicate your first sprite to create the starting point for your next sprite.

**Add me in: scratch-duplicating-sprite**

--- /task ---

--- task ---

Change the new sprite's costume or edit the costume with the paint editor so that it looks different from your first sprite. 

**Add me in: scratch-paint-tool-basics**


--- /task ---

--- task ---
Think about how this sprite will be different to the first sprite. 

How big should the sprite be? 
Which direction will it point in?

Will the sprite appear behind or in front or other sprites?
**Add me in: generic-scratch-layers**

Try different movement patterns: 

**Add me in: generic-scratch-spin-around**

**Add me in: generic-move-in-a-circle**

--- /task ---


--- task ---
Make sure you have selected the sprite that you want to change and click on the Code tab.

Change the code so that the new sprite does what you want it to.

--- /task ---

--- task ---
If you have time, you can keep adding more sprites. Make each one different to the others. 

--- /task ---

--- save ---

