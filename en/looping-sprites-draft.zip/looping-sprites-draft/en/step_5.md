## How to
Use these below drop-down tips to remind you how to do something if you are unsure or stuck. You can also pick up some additional techniques at any stage by exploring the tips.

[[[generic-scratch3-sprite-rotation-style]]]


scratch-graphic-effects

scratch-paint-ungroup

scratch-paint-eyedropper

