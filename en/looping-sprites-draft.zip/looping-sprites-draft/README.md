# looping-sprites

![looping-sprites](banner.png)

Find the project online at [projects.raspberrypi.org/en/projects/looping-sprites](https://projects.raspberrypi.org/en/projects/looping-sprites)

## Resources
For project materials and solutions, see [en/resources](https://github.com/raspberrypilearning/looping-sprites/tree/master/en/resources) and [en/solutions](https://github.com/raspberrypilearning/looping-sprites/tree/master/en/solutions).

## Contributing
See [CONTRIBUTING.md](CONTRIBUTING.md)

## Licence
 See [LICENCE.md](LICENCE.md)